#include "interface.h"

 int  Sensors_I2C_WriteRegister(uint16_t DEV_ADDR, uint16_t REG_ADDR, uint8_t size,uint8_t *buffer)
{

	uint32_t len = HAL_I2C_Master_Transmit_Mem_IT(IIC_ID, DEV_ADDR, REG_ADDR,
	                                         I2C_MEMADDR_SIZE_8BIT, buffer, size);
	if (len != size) {
		printf("to write size=%d, but i2c write size=%d\n", size, len);
		return -1;
	}

	return 0;
}

 int Sensors_I2C_ReadRegister(uint16_t DEV_ADDR, uint16_t REG_ADDR, uint8_t size,uint8_t *buffer)
{
    uint32_t len = HAL_I2C_Master_Receive_Mem_IT(IIC_ID, DEV_ADDR, REG_ADDR,
	                                        I2C_MEMADDR_SIZE_8BIT, buffer, size);
	if (len != size) {
		printf("to read size=%d, but i2c read size=%d\n", size, len);
		return -1;
	}

	return 0;
}

int TFT_SEND_CMD(uint8_t CMD)
{
	HAL_SPI_CS(SPI0, 1);
	TFT_CMD;
	uint8_t tmp = CMD;
	return HAL_SPI_Transmit(SPI0, &tmp, 1);

}

int TFT_SEND_DATAS(uint8_t *data,uint32_t size)
{
	HAL_SPI_CS(SPI0, 1);
	TFT_DATA;
	return HAL_SPI_Transmit(SPI0, data, size);
}

int TFT_SEND_DATA(uint8_t data)
{
	HAL_SPI_CS(SPI0, 1);
	TFT_DATA;
	uint8_t tmp = data;
	return HAL_SPI_Transmit(SPI0, &tmp, 1);
}
void SoftDelay_ms(float ms)
{
	OS_Sleep(ms/1000);
}


int dev_interface_init(void)
{
	HAL_Status status = HAL_ERROR;

/*************************************************/
/*GPIO INIT */
/*************************************************/

	/*IIC*/
    GPIO_InitParam param;
	param.driving = GPIO_DRIVING_LEVEL_1;
	param.mode = GPIOA_P12_F9_I2C0_SCL;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_A, GPIO_PIN_12, &param);

	param.driving = GPIO_DRIVING_LEVEL_1;
	param.mode = GPIOA_P13_F9_I2C0_SDA;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_A, GPIO_PIN_13, &param);

	/*SPI*/
	param.driving = GPIO_DRIVING_LEVEL_1;  //MOSI
	param.mode = GPIOB_P4_F2_SPI0_MOSI;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_B, GPIO_PIN_4, &param);

	param.driving = GPIO_DRIVING_LEVEL_1;  //MISO
	param.mode = GPIOB_P5_F2_SPI0_MISO;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_B, GPIO_PIN_5, &param);
	
	param.driving = GPIO_DRIVING_LEVEL_1;  //CS
	param.mode = GPIOB_P6_F2_SPI0_CS0;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_B, GPIO_PIN_6, &param);

	param.driving = GPIO_DRIVING_LEVEL_1; 	//CLK
	param.mode = GPIOB_P7_F2_SPI0_CLK;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_B, GPIO_PIN_7, &param);

	/*GPIO*/

	param.driving = GPIO_DRIVING_LEVEL_1;    //DC
	param.mode = GPIOx_Pn_F1_OUTPUT;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_B, GPIO_PIN_3, &param);

	param.driving = GPIO_DRIVING_LEVEL_1;	//RST
	param.mode = GPIOx_Pn_F1_OUTPUT;
	param.pull = GPIO_PULL_UP;
	HAL_GPIO_Init(GPIO_PORT_A, GPIO_PIN_19, &param);


/*************************************************/
/*IIC INIT */
/*************************************************/

	I2C_InitParam initParam;
	initParam.addrMode = I2C_ADDR_MODE_7BIT;
	initParam.clockFreq = IIC_FREQ;

	status = HAL_I2C_Init(IIC_ID, &initParam);
	if (status != HAL_OK) {
		printf("IIC init error %d\n", status);
		return -1;
	}


/*************************************************/
/*SPI INIT */
/*************************************************/
	SPI_Global_Config spi_param;

	spi_param.cs_level = 0;
	spi_param.mclk = 160000000;
	

	HAL_SPI_Init(SPI0, &spi_param);


	SPI_Config spi_Config;

	spi_Config.firstBit = SPI_TCTRL_FBS_MSB;
	spi_Config.mode = SPI_CTRL_MODE_MASTER;
	spi_Config.opMode = SPI_OPERATION_MODE_POLL;
	spi_Config.sclk = 80000000;
	spi_Config.sclkMode = SPI_SCLK_Mode0;

	printf("spi open...\n");
	status = HAL_SPI_Open(SPI0, SPI_TCTRL_SS_SEL_SS0, &spi_Config, 5000);
	if (status != HAL_OK) {
		printf("spi open failed");
		return status;
	}

	HAL_SPI_Config(SPI0, SPI_ATTRIBUTION_IO_MODE, SPI_IO_MODE_NORMAL);

	return 0;
}