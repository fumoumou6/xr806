#ifndef __INTERFACE_H__
#define __INTERFACE_H__

#include "common/framework/platform_init.h"
#include <stdio.h>
#include "kernel/os/os.h"

#include "driver/chip/hal_i2c.h"
#include "driver/chip/hal_gpio.h"
#include "driver/chip/hal_spi.h"

#define IIC_ID                  I2C0_ID
#define IIC_FREQ                400000

typedef int32_t s32 ;
typedef int16_t s16;
typedef uint32_t u32 ;
typedef uint16_t u16;
typedef uint8_t u8;


 int Sensors_I2C_WriteRegister(uint16_t DEV_ADDR, uint16_t REG_ADDR, uint8_t size, uint8_t *buffer);
 int Sensors_I2C_ReadRegister(uint16_t DEV_ADDR, uint16_t REG_ADDR, uint8_t size, uint8_t *buffer);
 int dev_interface_init(void);
 void SoftDelay_ms(float ms);

 int TFT_SEND_CMD(uint8_t CMD);
 int TFT_SEND_DATA(uint8_t data);
 int TFT_SEND_DATAS(uint8_t *data,uint32_t size);

#define TFT_CMD HAL_GPIO_WritePin(GPIO_PORT_B, GPIO_PIN_3, 0);
#define TFT_DATA HAL_GPIO_WritePin(GPIO_PORT_B, GPIO_PIN_3, 1);

#define TFT_RST HAL_GPIO_WritePin(GPIO_PORT_A, GPIO_PIN_19, 0);
#define TFT_SET HAL_GPIO_WritePin(GPIO_PORT_A, GPIO_PIN_19, 1);

#endif