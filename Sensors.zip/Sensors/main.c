/*
 * Copyright (C) 2017 XRADIO TECHNOLOGY CO., LTD. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the
 *       distribution.
 *    3. Neither the name of XRADIO TECHNOLOGY CO., LTD. nor the names of
 *       its contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "common/framework/platform_init.h"
#include <stdio.h>
#include "kernel/os/os.h"
#include "interface.h"
#include "./modules/BMP280.h"
#include "./modules/ATH20.h"
#include "./modules/st7789.h"
#include "./modules/mqtt.h"

#define SENSORS_THREAD_STACK_SIZE (1024)
static OS_Thread_t sensors_thread;

#define MQTT_THREAD_STACK_SIZE (8 * 1024)
OS_Thread_t mqtt_demo_thread;


static void sensors_fun(void *arg)
{
	dev_interface_init();
	BMP280_Init();
	ATH20_Init();
	TFT_init();

float pressure = 0;
float temperature = 0;
float asl = 0;
u32 CT = 0;
	TFT_full(0XFFFF);
	flush_words();
	while (1)
	{
		BMP280GetData(&pressure, &temperature, &asl);
		printf("pressure = %f temperature = %f asl = %f\r\n", pressure, temperature, asl);
		ATH20_Read_CTdata(&CT);
		printf("ct = %f%%\r\n", (float)(CT / 1000));
		flush_num(temperature, pressure, asl, CT / 1000);
		getMsg(pressure,temperature, asl, (float)(CT / 1000));
		OS_MSleep(300);
	}
	OS_ThreadDelete(&sensors_thread);
}

int main(void)
{
	platform_init();
	if (!OS_ThreadIsValid(&sensors_thread))
	{
		OS_ThreadCreate(&sensors_thread,
						"Sensors_thread",
						sensors_fun,
						(void *)NULL,
						OS_THREAD_PRIO_APP,
						SENSORS_THREAD_STACK_SIZE);
	}
	else
	{
		printf("Create Sensors_thread failed!\r\n");
	}

	if (!OS_ThreadIsValid(&mqtt_demo_thread))
	{
		OS_ThreadCreate(&mqtt_demo_thread,
						"mqtt_thread",
						mqtt_demo_fun,
						(void *)NULL,
						OS_THREAD_PRIO_APP,
						MQTT_THREAD_STACK_SIZE);
	}
	else
	{
		printf("Create mqtt_thread failed!\r\n");
	}
	while (1)
		;
	return 0;
}
