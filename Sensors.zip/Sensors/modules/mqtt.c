#include "mqtt.h"
static MQTTPacket_connectData mqtt_demo_connectData = MQTTPacket_connectData_initializer;
static Client mqtt_demo_client;
static Network mqtt_demo_network;

char *sta_ssid = "fumoumou";
char *sta_psk = "12345678";

char fifo[512] = {0};

void getMsg(float pressure, float temperature, float asl, float ct)
{
	sprintf(fifo, "温度 = %f°C, 湿度 = %f%%, 气压 = %fPa, 海拔 = %fM", (double)temperature,(double)ct/10,(double)pressure,(double)asl);
}

void sta_init(void)
{
	/* switch to sta mode */
	net_switch_mode(WLAN_MODE_STA);

	/* set ssid and password to wlan, use WPA2|WPA3 compatible mode to connect AP. */
	wlan_sta_set((uint8_t *)sta_ssid, strlen(sta_ssid), (uint8_t *)sta_psk);

	/* start scan and connect to ap automatically */
	wlan_sta_enable();

	OS_Sleep(10);

	/* After one minute, disconnect from AP */
	// wlan_sta_disable();
}

static int mqtt_demo_init(void)
{
	char *send_buf;
	char *recv_buf;

	/* init client id */
	mqtt_demo_connectData.clientID.cstring = MQTT_DEMO_CLIENT_ID;
	/* init keep alive interval */
	mqtt_demo_connectData.keepAliveInterval = 30; // 30s
	/* enable session reuse */
	mqtt_demo_connectData.cleansession = 0;
	/* set mqtt version */
	mqtt_demo_connectData.MQTTVersion = 4; // Version of MQTT 3.1.1

	/* send/recv buffer must free when mqtt deinit */
	send_buf = malloc(MQTT_DEMO_BUF_SIZE);
	if (send_buf == NULL)
	{
		printf("no memory\n");
		return -1;
	}
	recv_buf = malloc(MQTT_DEMO_BUF_SIZE);
	if (recv_buf == NULL)
	{
		free(send_buf);
		printf("no memory\n");
		return -1;
	}

	/* init network */
	NewNetwork(&mqtt_demo_network);
	/* init mqtt client object */
	MQTTClient(&mqtt_demo_client, &mqtt_demo_network, 6000,
			   (unsigned char *)send_buf, MQTT_DEMO_BUF_SIZE,
			   (unsigned char *)recv_buf, MQTT_DEMO_BUF_SIZE);

	/**
	 * set will function, when this client disconnect,
	 * server will sent the message to every client in MQTT_DEMO_TOPIC
	 */
	mqtt_demo_connectData.willFlag = 1;
	mqtt_demo_connectData.will.topicName.cstring = MQTT_DEMO_TOPIC;
	mqtt_demo_connectData.will.message.cstring = "I am disconnected";
	mqtt_demo_connectData.will.retained = 0;
	mqtt_demo_connectData.will.qos = 0;

	/* set username and password */
	mqtt_demo_connectData.username.cstring = MQTT_DEMO_USERNAME;
	mqtt_demo_connectData.password.cstring = MQTT_DEMO_PASSWORD;

	return 0;
}

static int mqtt_demo_connect(char *host_name, char *host_port)
{
	int ret = -1;

	/* need connect the server in tcp level first, if use ssl, use TLSConnectNetwork() */
	ret = ConnectNetwork(&mqtt_demo_network, host_name, atoi(host_port));
	if (ret != 0)
	{
		printf("mqtt connect faild, ret:%d, host:%s, port:%s\n", ret, host_name, host_port);
		goto exit;
	}

	/* if tcp level connected, then connect mqtt level */
	ret = MQTTConnect(&mqtt_demo_client, &mqtt_demo_connectData);
	if (ret != 0)
	{
		printf("mqtt connect faild, ret:%d\n", ret);
		/* disconnect the tcp level */
		mqtt_demo_network.disconnect(&mqtt_demo_network);
		goto exit;
	}
	printf("mqtt connected\n");

exit:
	return ret;
}

static void mqtt_demo_msg_cb(MessageData *data)
{
	printf("get a message, topic: %.*s, msg: %.*s\n", data->topicName->lenstring.len,
		   data->topicName->lenstring.data, data->message->payloadlen,
		   (char *)data->message->payload);
}

static int mqtt_demo_subscribe(char *topic)
{
	int ret = -1;

	if (mqtt_demo_client.isconnected)
	{
		/* set the message callback */
		ret = MQTTSubscribe(&mqtt_demo_client, topic, 0, mqtt_demo_msg_cb);
		if (ret != 0)
			printf("mqtt subscribe faild ret:%d\n", ret);
	}
	return ret;
}

static int mqtt_demo_unsubscribe(char *topic)
{
	int ret = -1;

	if (mqtt_demo_client.isconnected)
	{
		ret = MQTTUnsubscribe(&mqtt_demo_client, topic);
		if (ret != 0)
			printf("mqtt unsubscribe faild, ret:%d\n", ret);
	}
	return ret;
}

static int mqtt_demo_publish(char *topic, char *msg)
{
	int ret = -1;

	MQTTMessage message;

	memset(&message, 0, sizeof(message));
	message.qos = 0;
	message.retained = 0; /* disable retain the message in server */
	message.payload = msg;
	message.payloadlen = strlen(msg);

	ret = MQTTPublish(&mqtt_demo_client, topic, &message);
	if (ret != 0)
		printf("mqtt publish faild, ret:%d\n", ret);

	return ret;
}

static int mqtt_demo_disconnect(void)
{
	int ret = -1;

	if (mqtt_demo_client.isconnected)
	{
		/* need disconnect mqtt level first */
		ret = MQTTDisconnect(&mqtt_demo_client);
		if (ret != 0)
			printf("mqtt disconnect fail, ret:%d\n", ret);
		/* then disconnect tcp level */
		mqtt_demo_network.disconnect(&mqtt_demo_network);
	}

	return ret;
}

static void mqtt_demo_deinit(void)
{
	if (mqtt_demo_client.buf)
	{
		free(mqtt_demo_client.buf);
		mqtt_demo_client.buf = NULL;
	}
	if (mqtt_demo_client.readbuf)
	{
		free(mqtt_demo_client.readbuf);
		mqtt_demo_client.readbuf = NULL;
	}
}

void mqtt_demo_fun(void *arg)
{
	int ret;
	int reconnect_times = 0;

	/*wlan init */
	sta_init();

	/* mqtt init */
	mqtt_demo_init();

	/* mqtt connect */
	ret = mqtt_demo_connect(MQTT_DEMO_HOST_NAME, MQTT_DEMO_PORT);
	if (ret != 0)
		goto exit;

	/* subscribe topic */
	ret = mqtt_demo_subscribe(MQTT_DEMO_TOPIC);
	if (ret != 0)
		goto exit;

	while (1)
	{
		/* publish message to topic */
		mqtt_demo_publish(MQTT_DEMO_TOPIC, fifo);
		ret = MQTTYield(&mqtt_demo_client, 300);
		if (ret != 0)
		{
			printf("mqtt yield err, ret:%d\n", ret);
		reconnect:
			printf("mqtt reconnect\n");
			mqtt_demo_disconnect();
			ret = mqtt_demo_connect(MQTT_DEMO_HOST_NAME, MQTT_DEMO_PORT);
			if (ret != 0)
			{
				reconnect_times++;
				if (reconnect_times > 5)
					goto exit;
				OS_MSleep(5000); // 5s
				goto reconnect;
			}
		}
		OS_MSleep(1000); // 1s
	}

exit:
	mqtt_demo_unsubscribe(MQTT_DEMO_TOPIC);
	mqtt_demo_disconnect();
	mqtt_demo_deinit();

	// OS_ThreadDelete(&mqtt_demo_thread);
}