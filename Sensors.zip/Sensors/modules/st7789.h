#ifndef __ST7789_H__
#define __ST7789_H__

#include "common/framework/platform_init.h"
#include <stdio.h>
#include "kernel/os/os.h"
#include "interface.h"

#define TFT_COLUMN_NUMBER 240
#define TFT_LINE_NUMBER 280
#define TFT_COLUMN_OFFSET 0
#define TFT_LINE_OFFSET 20
#define PIC_NUM 28800 //

//
#define RED 0XF800
#define GREEN 0X07E0
#define BLUE 0X001F
#define BLACK 0X0000
#define PIC_LEN 120
#define PIC_HIG 120
#define PIC_NUMBER 28800

void TFT_init(void);
void TFT_full(unsigned int color);
void TFT_fulls(uint8_t *mat);
void TFT_SET_ADD(unsigned short int x_start, unsigned short int y_start, unsigned short int x_end, unsigned short int y_end);

void flush_word(unsigned short int start_x,unsigned short int start_y,const uint8_t* data,int color);
void flush_words(void);
void flush_num(float temp,float pressure,float asl,float ct);


#endif