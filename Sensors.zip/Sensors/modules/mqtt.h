#ifndef __MQTT_H_
#define __MQTT_H_

#include <stdio.h>
#include "kernel/os/os.h"
#include "common/framework/platform_init.h"
#include "net/wlan/wlan.h"
#include "common/framework/net_ctrl.h"
#include "net/mqtt/MQTTClient-C/MQTTClient.h"
#include "../interface.h"

#define MQTT_DEMO_CLIENT_ID "mqtt_sersors"
#define MQTT_DEMO_HOST_NAME "broker.emqx.io"
#define MQTT_DEMO_PORT      "1883"
#define MQTT_DEMO_USERNAME  "mqtt_sersors"
#define MQTT_DEMO_PASSWORD  "123456"
#define MQTT_DEMO_TOPIC     "/mqtt_sersors/data"

#define MQTT_DEMO_BUF_SIZE (2*1024)

#define MQTT_DEMO_MSG_TEXT "mqtt demo test"

void mqtt_demo_fun(void *arg);
void getMsg(float pressure, float temperature, float asl, float ct);
#endif